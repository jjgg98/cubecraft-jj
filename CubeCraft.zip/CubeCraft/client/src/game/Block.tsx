import { useBox } from '@react-three/cannon';
import { BlockType } from './types';
import { TEXTURES } from './textures';
import { Mesh } from 'three';
import { RefObject } from 'react';

interface BlockProps {
  position: [number, number, number];
  type: BlockType;
}

export default function Block({ position, type }: BlockProps) {
  const [ref] = useBox(() => ({
    type: 'Static',
    position,
    args: [1, 1, 1],
  })) as unknown as [RefObject<Mesh>];

  const material = TEXTURES[type];

  return (
    <mesh ref={ref} castShadow receiveShadow>
      <boxGeometry args={[1, 1, 1]} />
      {material && <primitive object={material} attach="material" />}
    </mesh>
  );
}