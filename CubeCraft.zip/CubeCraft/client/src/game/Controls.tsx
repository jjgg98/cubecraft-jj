import { useEffect, useState } from 'react';

const KEYS = {
  KeyW: 'moveForward',
  KeyS: 'moveBackward',
  KeyA: 'moveLeft',
  KeyD: 'moveRight',
  Space: 'jump',
} as const;

export function useKeyboard() {
  const [movement, setMovement] = useState({
    moveForward: false,
    moveBackward: false,
    moveLeft: false,
    moveRight: false,
    jump: false,
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.code as keyof typeof KEYS;
      if (key in KEYS) {
        setMovement((prev) => ({ ...prev, [KEYS[key]]: true }));
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.code as keyof typeof KEYS;
      if (key in KEYS) {
        setMovement((prev) => ({ ...prev, [KEYS[key]]: false }));
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return movement;
}
