import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { BLOCK_TYPES, BlockType } from './types';
import { TEXTURES } from './textures';

export default function Inventory() {
  const [selectedBlock, setSelectedBlock] = useState<BlockType>(BLOCK_TYPES[0]);

  return (
    <Card className="fixed bottom-4 left-1/2 transform -translate-x-1/2 p-4 flex gap-2 bg-background/90 backdrop-blur shadow-xl">
      {BLOCK_TYPES.map((blockType) => {
        const material = TEXTURES[blockType];
        const isSelected = selectedBlock === blockType;

        return (
          <div
            key={blockType}
            className={`
              w-14 h-14 
              cursor-pointer 
              rounded-md 
              transition-all 
              duration-200 
              ${isSelected ? 'ring-4 ring-primary scale-110' : 'hover:scale-105'}
            `}
            onClick={() => setSelectedBlock(blockType)}
          >
            <div 
              className="w-full h-full rounded-md flex items-center justify-center relative"
              style={{
                backgroundColor: (material as any).color.getStyle(),
                boxShadow: 'inset 0 2px 4px rgba(255,255,255,0.3), inset 0 -2px 4px rgba(0,0,0,0.4)'
              }}
            >
              <div className="absolute inset-0 rounded-md" 
                style={{
                  background: 'linear-gradient(45deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%)'
                }}
              />
              <span className="text-xs font-medium text-white/90 capitalize drop-shadow-md">
                {blockType}
              </span>
            </div>
          </div>
        );
      })}
    </Card>
  );
}