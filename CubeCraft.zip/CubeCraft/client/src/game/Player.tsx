import { useEffect, useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { useSphere } from '@react-three/cannon';
import * as THREE from 'three';
import { useKeyboard } from './Controls';
import { GRAVITY, PLAYER_SPEED, JUMP_FORCE } from './config';
import { Mesh } from 'three';
import { RefObject } from 'react';

export default function Player() {
  const { camera } = useThree();
  const { moveForward, moveBackward, moveLeft, moveRight, jump } = useKeyboard();

  const [ref, api] = useSphere(() => ({
    mass: 1,
    type: "Dynamic",
    position: [0, 5, 0],
    fixedRotation: true,
    linearDamping: 0.9,
  })) as unknown as [RefObject<Mesh>, any];

  const pos = useRef([0, 0, 0]);
  const vel = useRef([0, 0, 0]);

  // Mouse look controls
  const rotation = useRef({ x: 0, y: 0 });
  const PI_2 = Math.PI / 2;

  useEffect(() => {
    api.position.subscribe((p: number[]) => (pos.current = p));
    api.velocity.subscribe((v: number[]) => (vel.current = v));
  }, [api]);

  useEffect(() => {
    // Apply constant gravity
    api.applyForce([0, GRAVITY, 0], [0, 0, 0]);
  }, [api]);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      rotation.current.y -= event.movementX * 0.002;
      rotation.current.x -= event.movementY * 0.002;
      rotation.current.x = Math.max(-PI_2, Math.min(PI_2, rotation.current.x));
    };

    document.addEventListener('mousemove', handleMouseMove);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  useFrame(() => {
    // Update camera position to follow player
    camera.position.copy(new THREE.Vector3(pos.current[0], pos.current[1] + 1.6, pos.current[2]));

    // Update camera rotation from mouse look
    camera.rotation.x = rotation.current.x;
    camera.rotation.y = rotation.current.y;

    const direction = new THREE.Vector3();
    const frontVector = new THREE.Vector3(
      0,
      0,
      (moveBackward ? 1 : 0) - (moveForward ? 1 : 0)
    );
    const sideVector = new THREE.Vector3(
      (moveLeft ? 1 : 0) - (moveRight ? 1 : 0),
      0,
      0
    );

    direction
      .subVectors(frontVector, sideVector)
      .normalize()
      .multiplyScalar(PLAYER_SPEED)
      .applyEuler(camera.rotation);

    api.velocity.set(direction.x, vel.current[1], direction.z);

    // Only allow jumping when near the ground
    if (jump && Math.abs(vel.current[1]) < 0.05) {
      api.velocity.set(vel.current[0], JUMP_FORCE, vel.current[2]);
    }
  });

  return <mesh ref={ref} />;
}