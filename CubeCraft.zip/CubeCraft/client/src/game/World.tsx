import { useEffect, useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Physics, usePlane } from '@react-three/cannon';
import Player from './Player';
import Block from './Block';
import { CHUNK_SIZE, WORLD_SIZE } from './config';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Mesh } from 'three';
import { RefObject } from 'react';
import { Block as BlockType } from './types';

function Ground() {
  const [ref] = usePlane(() => ({ 
    rotation: [-Math.PI / 2, 0, 0],
    position: [0, -0.5, 0]
  })) as unknown as [RefObject<Mesh>];

  return (
    <mesh ref={ref} receiveShadow>
      <planeGeometry args={[1000, 1000]} />
      <meshStandardMaterial 
        color="#5C832F" 
        roughness={1}
        metalness={0}
      />
    </mesh>
  );
}

export default function World() {
  const { camera, scene } = useThree();
  const worldId = 1; // Hardcoded for demo

  useEffect(() => {
    // Add fog for depth perception
    scene.fog = new THREE.Fog('#87CEEB', 1, WORLD_SIZE * CHUNK_SIZE);
    scene.background = new THREE.Color('#87CEEB');
  }, [scene]);

  // Load world data
  const { data: world } = useQuery({
    queryKey: ['/api/worlds/' + worldId],
  });

  // Save world mutation
  const { mutate: saveWorld } = useMutation({
    mutationFn: async (blocks: any[]) => {
      await apiRequest('POST', `/api/worlds/${worldId}`, { blocks });
    }
  });

  // Generate initial blocks if no saved world or empty blocks
  useEffect(() => {
    if (!world || !world.blocks || world.blocks.length === 0) {
      const blocks = [];
      // Generate terrain with different block types
      for (let x = -WORLD_SIZE; x < WORLD_SIZE; x++) {
        for (let z = -WORLD_SIZE; z < WORLD_SIZE; z++) {
          // Add ground layer
          blocks.push({ x, y: -1, z, type: 'grass' });

          // Add some random terrain features
          if (Math.random() > 0.8) {
            const height = Math.floor(Math.random() * 3) + 1;
            for (let y = 0; y < height; y++) {
              blocks.push({ x, y, z, type: 'dirt' });
            }
          }

          // Add some stone blocks
          if (Math.random() > 0.9) {
            blocks.push({ x, y: 0, z, type: 'stone' });
          }
        }
      }
      saveWorld(blocks);
    }
  }, [world, saveWorld]);

  return (
    <>
      {/* Main lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight 
        position={[10, 20, 5]} 
        intensity={1} 
        castShadow
        shadow-mapSize={[2048, 2048]}
      />

      {/* Hemisphere light for better ambient lighting */}
      <hemisphereLight 
        skyColor="#87CEEB" 
        groundColor="#5C832F" 
        intensity={0.5} 
      />

      <Physics gravity={[0, -9.81, 0]}>
        <Ground />
        <Player />

        {world?.blocks && world.blocks.map((block: any, i: number) => (
          <Block
            key={i}
            position={[block.x, block.y, block.z]}
            type={block.type}
          />
        ))}
      </Physics>
    </>
  );
}