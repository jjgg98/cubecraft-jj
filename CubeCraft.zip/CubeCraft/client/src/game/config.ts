export const CHUNK_SIZE = 16;
export const WORLD_SIZE = 8; // In chunks
export const BLOCK_SIZE = 1;

export const GRAVITY = -9.81;
export const PLAYER_SPEED = 5;
export const JUMP_FORCE = 4;
