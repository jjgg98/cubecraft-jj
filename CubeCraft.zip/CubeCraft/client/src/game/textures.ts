import * as THREE from 'three';
import { BlockType } from './types';

// Create enhanced materials for each block type with better visual properties
const createBlockMaterial = (color: string) => {
  return new THREE.MeshStandardMaterial({ 
    color,
    roughness: 0.8,
    metalness: 0.1,
    flatShading: true
  });
};

export const TEXTURES: Record<BlockType, THREE.Material> = {
  grass: createBlockMaterial('#4CAF50'), // Vibrant grass green
  dirt: createBlockMaterial('#8B4513'),  // Rich brown
  stone: createBlockMaterial('#607D8B'), // Blue-grey stone
  wood: createBlockMaterial('#795548'),  // Deep brown wood
  leaves: createBlockMaterial('#2E7D32'), // Dark forest green
};