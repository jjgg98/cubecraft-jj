export const BLOCK_TYPES = ['grass', 'dirt', 'stone', 'wood', 'leaves'] as const;
export type BlockType = typeof BLOCK_TYPES[number];

export interface Block {
  position: [number, number, number];
  type: BlockType;
}
