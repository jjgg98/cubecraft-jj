import { Canvas } from '@react-three/fiber';
import World from '../game/World';
import Inventory from '../game/Inventory';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const [started, setStarted] = useState(false);
  const { toast } = useToast();

  const handleStart = () => {
    setStarted(true);
    toast({
      title: "Game Started",
      description: "Use WASD to move, Space to jump. Move your mouse to look around. Left click to destroy blocks, Right click to place blocks"
    });
  };

  if (!started) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-8">Minecraft Clone</h1>
          <Button onClick={handleStart}>Start Game</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Canvas
        shadows
        camera={{ 
          fov: 70, 
          position: [0, 1.6, 5],
          near: 0.1,
          far: 1000
        }}
        style={{ height: '100vh', width: '100%' }}
      >
        <World />
      </Canvas>
      <Inventory />
    </>
  );
}