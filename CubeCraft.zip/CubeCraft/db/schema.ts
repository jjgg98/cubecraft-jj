import { pgTable, text, serial, bigint, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const worlds = pgTable("worlds", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  blocks: jsonb("blocks").notNull().$type<{x: number, y: number, z: number, type: string}[]>(),
  lastSaved: bigint("last_saved", { mode: "number" }).notNull(),
});

export const insertWorldSchema = createInsertSchema(worlds);
export const selectWorldSchema = createSelectSchema(worlds);
export type World = typeof worlds.$inferSelect;
export type NewWorld = typeof worlds.$inferInsert;